# ES5 React Webpack Boilerplate

## Why yet another template?

Because I can.

![standards](https://cloud.githubusercontent.com/assets/829292/12536852/66dc5b1a-c2b1-11e5-8c23-bec83c0d93bd.png)

## No, seriously

Because I wanted a boilerplate that was:

* Simple
* Use Webpack
* Hotreload
* ES5

Most of the boilerplates I found where using ES6, which I can't for now.

## Why create a boilerplate?

I'm giving a training on React and I need a common base for my students.

## Did you do that yourself?

No. this is heavily inspired by [Dan Abramov Boilerplate](https://github.com/gaearon/react-hot-boilerplate) - my big thanks to him for his work.

## How to use:

```bash
npm start # start the dev, hot reload server
npm build # build the production version
```